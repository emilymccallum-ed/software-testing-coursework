package uk.ac.ed.inf;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;

public class Order {

    /**
     * String: order ID number
     */
    @JsonProperty("orderNo")
    private String orderNo;
    /**
     * String: date of order
     */
    @JsonProperty ("orderDate")
    private String orderDate;
    /**
     * String: customer name ("[firstname] [surname]")
     */
    @JsonProperty ("customer")
    private String customer;
    /**
     * String: Credit card number
     */
    @JsonProperty ("creditCardNumber")
    private String creditCardNumber;
    /**
     * String: Credit card expiry date
     */
    @JsonProperty ("creditCardExpiry")
    private String creditCardExpiry;
    /**
     * String: Cvv
     */
    @JsonProperty ("cvv")
    private String cvv;
    /**
     * Int: Total price of order, in pence
     */
    @JsonProperty ("priceTotalInPence")
    private int priceTotalInPence;
    /**
     * String Array: order item names (pizza names)
     */
    @JsonProperty ("orderItems")
    private String[] orderItems;
    /**
     * Enum value: order outcome
     */
    private OrderOutcome outcome;

    /**
     * Restaurant belonging to order
     */
    private Restaurant restaurant;
    /**
     * Angle to next move
     */
    private double angle;

    /**
     * Int CONST minimum charge for an order
     */
    private static final int FIXED_ORDER_COST = 100;

    /**
     * Constructor
     */
    private Order(){}

    /**
     * Gets list of all orders from Rest server
     * @return Order[] list of orders
     */
    public static Order[] getOrdersFromRESTServer() {
        return InputOutput.deserialize("/orders", new TypeReference<>() {});
    }

    /**
     * Returns total delivery cost of an order, including fixed £1 delivery charge.
     * @return int total delivery cost
     */
    public int getDeliveryCost() {
        return (FIXED_ORDER_COST + this.priceTotalInPence);
    }

    /**
     * Getter
     * @return orderNo
     */
    public String getOrderNo() {return orderNo;}

    /**
     * Getter
     * @return orderDate
     */
    public String getOrderDate() {return orderDate;}

    /**
     * Getter
     * @return customer
     */
    public String getCustomer() {return customer;}

    /**
     * Getter
     * @return  creditCardNumber
     */
    public String getCreditCardNumber() {return creditCardNumber;}

    /**
     * Getter
     * @return creditCardExpiry
     */
    public String getCreditCardExpiry() {return creditCardExpiry;}

    /**
     * Getter
     * @return cvv
     */
    public String getCvv() {return cvv;}

    /**
     * Getter
     * @return priceTotalInPence
     */
    public int getPriceTotalInPence() {return priceTotalInPence;}

    /**
     * Getter
     * @return orderItems
     */
    public String[] getOrderItems() {return orderItems;}

    /**
     * Setter
     * @param outcome OrderOutcome
     */
    public void setOutcome(OrderOutcome outcome) {this.outcome = outcome;}

    /**
     * Getter
     * @return outcome OrderOutcome
     */
    public OrderOutcome getOutcome() {return this.outcome;}

    /**
     * Getter
     * @return Restaurant
     */
    public Restaurant getRestaurant() {return this.restaurant;}

    /**
     * Setter
     * @param restaurant Restaurant
     */
    public void setRestaurant(Restaurant restaurant) {this.restaurant = restaurant;}

    /**
     * Getter
     * @return angle
     */
    public double getAngle() {return this.angle;}

    /**
     * Setter
     * @param angle double
     */
    public void setAngle(double angle) {this.angle = angle;}
}
