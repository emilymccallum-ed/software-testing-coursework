package uk.ac.ed.inf;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Class storing properties of MenuItem, i.e. pizza
 */
public class MenuItem {

    /**
     * Name of menu item, i.e. pizza name
     */
    @JsonProperty("name")
    private String name;

    /**
     * Price of pizza in pence
     */
    @JsonProperty("priceInPence")
    private int priceInPence;

    /**
     * JsonCreator for deserialization
     * @param name String
     * @param priceInPence int
     */
    @JsonCreator
    private MenuItem(@JsonProperty("name") String name, @JsonProperty("priceInPence") int priceInPence) {
        this.name = name;
        this.priceInPence = priceInPence;
    }

    /**
     * Getter
     * @return name String of menuItem
     */
    @JsonProperty("name")
    public String getName() {return name;}

    /**
     * Setter
     * @param name String
     */
    @JsonProperty("name")
    public void setName(String name) {this.name = name;}

    /**
     * Getter
     * @return priceInPence of menu item
     */
    @JsonProperty("priceInPence")
    public int getPriceInPence() {return priceInPence;}

    /**
     * Setter
     * @param priceInPence of menu item
     */
    @JsonProperty("priceInPence")
    public void setPriceInPence(int priceInPence) {this.priceInPence = priceInPence;}
}
