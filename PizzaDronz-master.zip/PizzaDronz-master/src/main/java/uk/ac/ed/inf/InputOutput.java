package uk.ac.ed.inf;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.FileWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Class to serialize and deserialize data from the Rest server.
 */
public class InputOutput {

    /**
     * Constructor
     */
    public InputOutput() {}

    /**
     * Retrieves data at input endpoint and deserializes to Java objects
     * @return baseURL URL for Rest API without any endpoints
     */

    public static <T> T deserialize(String endpoint, TypeReference <T> T) {
        URL finalURL = null;
        T response = null;

        try {
            finalURL = new URL(Data.getBaseURL().toString() + endpoint);
        }
        catch (MalformedURLException e) {
            System.err.println("URL is invalid: " + Data.getBaseURL() + endpoint);
            System.exit(2);
        }

        try {
            response = new ObjectMapper().readValue(finalURL, T);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        return response;
    }

    /**
     * Serializes final orders list to deliveries file
     */
    public static ArrayList<JsonObject> getJsonDeliveries() {
        ArrayList<JsonObject> deliveries = new ArrayList<>();
        List<Order> finalOrders = Flightpath.getFinalOrders();
        if (finalOrders.size() > 0) {
            for (Order order : finalOrders) {
                if (order.getOutcome() == OrderOutcome.DELIVERED) {
                    JsonObject json = new JsonObject();
                    json.addProperty("orderNo", order.getOrderNo());
                    json.addProperty("outcome", order.getOutcome().toString());
                    json.addProperty("costInPence", order.getDeliveryCost());
                    deliveries.add(json);
                }
            }
        }

        return deliveries;
    }

    /**
     * Serializes final set of flightpath moves to Json
     * @return
     */
    public static ArrayList<JsonObject> getJsonFlightpath() {
        ArrayList<JsonObject> flightpath = new ArrayList<>();
        for (Move move : Flightpath.getFinalMoves()) {
            JsonObject json = new JsonObject();
            json.addProperty("orderNo", move.getOrderNo());
            json.addProperty("fromLongitude", move.getFromLongitude());
            json.addProperty("fromLatitiude", move.getFromLatitude());
            json.addProperty("angle", move.getAngle());
            json.addProperty("toLongitude", move.getToLongitude());
            json.addProperty("toLatitiude", move.getToLatitude());
            json.addProperty("ticksSinceStartOfCalculation", move.getTotalTicks());
            flightpath.add(json);
        }
        return flightpath;
    }

    /**
     * Writes Json string to file
     * @param filename
     * @param fileData
     */
    public static void writeToFile(String filename, String fileData) {
        try {
            FileWriter writer = new FileWriter(filename);
            writer.write(fileData);
            writer.close();
            System.out.println("Success - wrote content to file.");
        } catch (IOException e) {
            System.err.println("Error - could not write to file\n" + e.getMessage());
        }
    }

    /**
     * Writes deliveries Json to file
     */
    public static void writeDeliveriesFile() {
        Gson gson = new Gson();
        String deliveriesJson = gson.toJson(getJsonDeliveries());
        String filename = "deliveries-" + Data.getOrderDate().toString() + ".json";
        writeToFile(filename, deliveriesJson);
    }

    /**
     * Writes flightpath Json to file
     */
    public static void writeFlightpathFile() {
        Gson gson = new Gson();
        String filepathJson = gson.toJson(getJsonFlightpath());
        String filename = "flightpath-" + Data.getOrderDate().toString() + ".json";
        writeToFile(filename, filepathJson);
    }

    /**
     * Writes locations of each drone move to file in GeoJson
     */
    public static void writeDronePathFile() {
        writeToFile("drone-" + Data.getOrderDate().toString() + ".geojson", Flightpath.getFlightpathGeoJson());
    }


}
