package uk.ac.ed.inf;

/**
 * Custom Exception class for general OrderOutcome exception
 * Each OrderOutcome exception will pass in the respective outcome's message
 */
public class InvalidOrderException extends Exception {
    /**
     * Call Exception constructor with custom exception message
     * @param outcome OrderOutcome
     */
    public InvalidOrderException(OrderOutcome outcome) {
        super("Error: " + outcome.toString());
    }

}
