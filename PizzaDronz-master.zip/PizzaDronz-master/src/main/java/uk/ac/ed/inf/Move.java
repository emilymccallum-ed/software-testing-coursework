package uk.ac.ed.inf;

public class Move {

    private String orderNo;
    private float fromLongitude;
    private float fromLatitude;
    private float angle;
    private float toLongitude;
    private float toLatitude;
    private long totalTicks;

    public void Move() {}

    public String getOrderNo() {return this.orderNo;}

    public void setOrderNo(String orderNo) {this.orderNo = orderNo;}

    public float getFromLongitude() {return this.fromLongitude;}

    public void setFromLongitude(float fromLongitude) {this.fromLongitude = fromLongitude;}

    public float getFromLatitude() {return this.fromLatitude;}

    public void setFromLatitude(float fromLatitude) {this.fromLatitude = fromLatitude;}

    public float getAngle() {return this.angle;}

    public void setAngle(float angle) {this.angle = angle;}

    public float getToLongitude() {return this.toLongitude;}

    public void setToLongitude(float toLongitude) {this.fromLatitude = fromLatitude;}

    public float getToLatitude() {return this.toLatitude;}

    public void setToLatitude(float toLatitude) {this.toLatitude = toLatitude;}

    public long getTotalTicks() {return this.totalTicks;}

    public void setTotalTicks(long totalTicks) {this.totalTicks = totalTicks;}
}