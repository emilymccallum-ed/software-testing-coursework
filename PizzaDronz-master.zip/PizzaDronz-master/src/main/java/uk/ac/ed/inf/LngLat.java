package uk.ac.ed.inf;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * Record storing longitude and latitude of a point. Treated like a planar point.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record LngLat(@JsonProperty("longitude") double lng, @JsonProperty("latitude") double lat) {
    /**
     * Json creator so separate lng and lat values can be unwrapped to LngLat
     */
    @JsonCreator
    public LngLat {
    }

    /**
     * Constant amount a drone can move = 0.00015
     */
    private static final double MOVE_DISTANCE = 0.00015;

    /**
     * Checks if a LngLat point is inside or outside an area's boundaries.
     * Uses the even-odd algorithm.
     * Reference: <a href="https://www.geeksforgeeks.org/how-to-check-if-a-given-point-lies-inside-a-polygon/">...</a>
     * Case 1: Checks for collinearity (i.e. if a point is on the border).
     * Case 2: Checks for how many times an infinite horizontal line drawn from the point crosses the Central Area polygon boundaries.
     * If it crosses an even number of times, the point is outside the polygon.
     * If it crosses an odd number of times, the point in inside the polygon.
     *
     * @return Boolean - true if point is in Central Area
     */
    public Boolean inArea(List<LngLat> points) {
        // If it's not a valid polygon because it has less than 3 points, a point cannot be inside it
        if (points.size() < 3)
            return false;

        LngLat infinity = new LngLat(Integer.MAX_VALUE, this.lat);

        // Number of points in polygon whose latitude is equal to the point's latitude.
        int decrease = 0;

        // Count number of intersections of polygon with point->infinity vector
        int count = 0, i = 0;
        do {
            int next = (i + 1) % points.size();
            if (points.get(i).lat == this.lat)
                decrease++;

            // Check if line (testPoint to Infinity) intersects with line segment of (points(i) to points(next))
            if (checkIntersect(points.get(i), points.get(next), this, infinity)) {
                // If testPoint is collinear with line segment (i to next), check if it lies on the line segment ? true : false
                if (orientation(points.get(i), this, points.get(next)) == 0) {
                    return checkCollinear(points.get(i), this, points.get(next));
                }

                count++;
            }
            i = next;
        } while (i != 0);

        // Reduce intersections by decrease amount, as these points would have been added twice
        count -= decrease;

        // Return true if count is odd; otherwise return false
        return (count % 2 == 1);
    }

    /**
     * Returns orientation of 3 joined points
     *
     * @param p - a LngLat point
     * @param q - a LngLat point
     * @param r - a LngLat point
     * @return 0 for collinear, 1 for clockwise, 2 for anti-clockwise
     */
    private int orientation(LngLat p, LngLat q, LngLat r) {
        double val = (q.lat - p.lat) * (r.lng - q.lng) - (q.lng - p.lng) * (r.lat - q.lat);

        // Collinear
        if (val == 0)
            return 0;

        // Clockwise
        if (val > 0)
            return 1;

        // Anti-Clockwise
        return 2;
    }

    /**
     * Given 3 collinear points: p, q, and r
     * Check if point q is on the pr line segment (i.e. between them)
     *
     * @param p - a LngLat point
     * @param q - a LngLat point
     * @param r - a LngLat point
     * @return Boolean - true if points are collinear; else false
     */
    private Boolean checkCollinear(LngLat p, LngLat q, LngLat r) {
        // If q lies between the max and min lng of pr, and the max and min lat of pr
        // Then q must lie between pq on the line segment pr
        double maxLng = Math.max(p.lng, r.lng);
        double minLng = Math.min(p.lng, r.lng);
        double maxLat = Math.max(p.lat, r.lat);
        double minLat = Math.min(p.lat, r.lat);

        return q.lng <= maxLng &&
                q.lng >= minLng &&
                q.lat <= maxLat &&
                q.lat >= minLat;
    }

    /**
     * Check if lines pq and ab intersect
     * CASE 1: Out of 4 possible orientation pairings,
     * If the first pair of orientations are different, and the second pair are different, then the lines intersect
     * CASE 2: Checks all possible cases of collinear intersection
     *
     * @param p - a LngLat point
     * @param q - a LngLat point
     * @param a - a LngLat point
     * @param b - a LngLat point
     * @return Boolean - true if lines pq and ab intersect; else false
     */
    // Checks if lines pq and ab intersect
    private Boolean checkIntersect(LngLat p, LngLat q, LngLat a, LngLat b) {
        // Find four orientations needed for general and special cases
        int or1 = orientation(p, q, a);
        int or2 = orientation(p, q, b);
        int or3 = orientation(a, b, p);
        int or4 = orientation(a, b, q);

        /* CASE 1: Check if two lines intersect (and are not collinear)
            If the first two orientation are different AND the second two orientations are different,
            Then the lines intersect
         */
        if (or1 != or2 && or3 != or4)
            return true;

        /* CASE 2: Check if they are Collinear Points
            (i) p, q, and a are collinear
            And a lies on line pq=
         */
        if (or1 == 0 && checkCollinear(p, a, q))
            return true;

        /* (ii) p, q, and a are collinear
            And b lies on line pq
         */
        if (or2 == 0 && checkCollinear(p, b, q))
            return true;

        /* (iii)) a, b, and p are collinear
            And p lies on line ab
         */
        if (or3 == 0 && checkCollinear(a, p, b))
            return true;

        /* (iv) a, b, and q are collinear
            And q lies on ab
         */
        return or4 == 0 && checkCollinear(a, q, b);
    }

    /**
     * Finds the distance between two coordinate points.
     *
     * @param point other LngLat point
     * @return double distance
     */
    public double distanceTo(LngLat point) {
        // distance = sqrt((x2-x1)^2 + (y2-y1)^2)
        double lngDist = point.lng - this.lng;
        double latDist = point.lat - this.lat;
        return Math.sqrt(lngDist * lngDist + latDist * latDist);
    }

    /**
     * Checks if the distance between two points is smaller than one move, i.e.  "close".
     * @param lngLat other LngLat point
     * @return Boolean - true if "close"; else false
     */
    public Boolean closeTo(LngLat lngLat) {
        return (distanceTo(lngLat) < MOVE_DISTANCE);
    }

    /**
     * Returns a LngLat object representing the new position if the drone makes a move in the input direction.
     *
     * @param d Direction Enum
     * @return LngLat nextPosition
     */
    public LngLat nextPosition(Direction d) {
        if (d == Direction.Hover) {
            return this;
        }
        double newLng = this.lng + LngLat.MOVE_DISTANCE * Math.cos(Math.toRadians(d.getAngle()));
        double newLat = this.lat + LngLat.MOVE_DISTANCE * Math.sin(Math.toRadians(d.getAngle()));
        return new LngLat(newLng, newLat);
    }

    /**
     * Getter
     * @return longitude double
     */
    public double getLng() {
        return this.lng;
    }

    /**
     * Getter
     * @return latitude double
     */
    public double getLat() {
        return this.lat;
    }
}