package uk.ac.ed.inf;

import com.mapbox.geojson.*;

import java.util.*;

/**
 * Class to calculate optimal flightpath of drone, limited to 2000 moves per day
 */
public class Flightpath {

    private final static LngLat APPLETON_LOCATION = new LngLat(-3.186874,55.944494);
    private static Order currentOrder;
    private static LngLat currOrderDestination;
    private static LngLat actualDronePos = APPLETON_LOCATION;
    private static LngLat tempDronePos = APPLETON_LOCATION;
    private static List<LngLat> fullPath = new ArrayList<>();
    private static List<LngLat> orderPath = new ArrayList<>();
    private static List<Order> finalOrders = new ArrayList<>();
    private static List<Move> finalMoves = new ArrayList<>();
    private static List<Move> orderMoves = new ArrayList<>();
    private static int totalMoves = 0;
    private static int numOrderMoves = 0;
    private static int numOrders = 0;

    /**
     * Calculates flightpath
     * @return flightpath locations in GeoJson format
     */
    public static String getFlightpath() {
        setRestaurantDists();
        prioritiseOrders();
        System.out.println("Num of valid orders: " + Data.getValidOrders().length);
        for (Order order : Data.getValidOrders()) {
            currentOrder = order;
            currOrderDestination = currentOrder.getRestaurant().getLocation();
            orderPath.add(tempDronePos); // Add Appleton as first point
            setOrderPath();
            Boolean added = addOrDiscardOrder();
            resetOrderCalc();
            if (!added)
                break;
        }
        return Flightpath.getFlightpathGeoJson();
    }

    /**
     * Set distances between each restaurant and Appleton
     */
    private static void setRestaurantDists() {
        // For each restaurant
        for (Restaurant restaurant : Data.getRestaurants()) {
            // Set the distance between it and Appleton Tower
            restaurant.setDistFromAT(restaurant.getLocation().distanceTo(APPLETON_LOCATION));
        }
    }

    /**
     * Sort list of valid orders based on their restaurant's distance to Appleton (the closest first)
     */
    private static void prioritiseOrders() {
        Arrays.sort(Data.getValidOrders(), Comparator.comparing(order->order.getRestaurant().getDistFromAT()));
    }

    /**
     * Find the closest Direction to desired angle to get from current position to order location
     * i.e. round to nearest 22.5
     */

    private static Direction getClosestDirection() {
        // Find angle between current position and order location
        double lngDist = currOrderDestination.getLng() - tempDronePos.getLng();
        double latDist = currOrderDestination.getLat() - tempDronePos.getLat();
        double angle = Math.toDegrees(Math.atan2(latDist, lngDist));
        // Convert negative angles in range -180<x<180 to positive angles in range (0<x<360)
        if (angle < 0) {
            angle = 360 + angle;
        }
        //System.out.println("angle: " + angle);

        // Find direction closest to angle, rounded by 22.5
        double roundedAngle = Math.round(angle/22.5) * 22.5;
        //System.out.println("rounded angle: " + roundedAngle);
        for (Direction d : Direction.values()) {
            if (d.getAngle() == roundedAngle) {
                //System.out.println(d);
                return d;
            }
        }
        System.err.println("Could not find closest direction to order angle.");
        return null;
    }

    /**
     * Decide whether moving to an order, and back to AT, would go over the 2000 moves limit
     * Discard or add order to flightpath accordingly
     * @return 1 or 0 -> Added order or discarded order
     */
    private static Boolean addOrDiscardOrder() {
        // If totalMoves + orderMoves * 2 (for return journey to AT) is over 2000 moves limit
        if (totalMoves + numOrderMoves > 2000) {
            // Discard order
            currentOrder.setOutcome(OrderOutcome.VALID_BUT_NOT_DELIVERED);
            System.out.println(currentOrder.getOrderNo() + " " + currentOrder.getRestaurant() + " " + currentOrder.getOutcome() + " " + numOrders);
            return false;
        }
        // Otherwise add order to flightpath (including reverse path)
        fullPath.addAll(orderPath);
        finalOrders.add(currentOrder);
        finalMoves.addAll(orderMoves);
        totalMoves += numOrderMoves;
        actualDronePos = tempDronePos;
        currentOrder.setOutcome(OrderOutcome.DELIVERED);
        numOrders += 1;
        System.out.println(currentOrder.getOrderNo() + " " + currentOrder.getRestaurant().getName() + " " + currentOrder.getOutcome() + " " + numOrders);
        System.out.println(totalMoves);

        resetOrderCalc();
        // If at limit, return false
        if (totalMoves + numOrderMoves == 2000)
            return false;
        // If under limit return true
        return true;
    }

    /**
     * Find how many moves it takes to get from Appleton to the order restaurant
     */
    private static void setOrderPath() {
        tempDronePos = APPLETON_LOCATION;
        while (!tempDronePos.closeTo(currOrderDestination)) {
            orderMoves.add(move1ToOrder());
            numOrderMoves += 1;
        }
        numOrderMoves += 1; // hover at restaurant
        addHoverMove();
        addReverseOrderPath();
        addHoverMove();
        numOrderMoves *=2; // moves *2 for reverse path
        numOrderMoves += 1; // hover at Appleton
    }

    private static void addHoverMove() {
        Move move = new Move();
        move.setOrderNo(currentOrder.getOrderNo());
        move.setFromLongitude((float) tempDronePos.getLng());
        move.setFromLatitude((float) tempDronePos.getLat());
        move.setToLongitude((float) tempDronePos.getLng());
        move.setToLatitude((float) tempDronePos.getLat());
        move.setAngle(-1);
        move.setTotalTicks(System.nanoTime());
        orderMoves.add(move);
    }

    /**
     * Move 1 step (0.00015) towards the order in the desired direction
     */
    private static Move move1ToOrder() {
        Direction closestDirection = getClosestDirection();
        // Set up move with current lng, lat, angle to next pos, lng and lat of next pos, and ticks
        Move move = new Move();
        move.setOrderNo(currentOrder.getOrderNo());
        move.setFromLongitude((float) tempDronePos.getLng());
        move.setFromLatitude((float) tempDronePos.getLat());
        move.setAngle((float)closestDirection.getAngle());
        // Set new tempDronePos
        LngLat newPos = tempDronePos.nextPosition(closestDirection);
        tempDronePos = newPos;
        move.setToLongitude((float)tempDronePos.getLng());
        move.setToLatitude((float)tempDronePos.getLat());
        move.setTotalTicks(System.nanoTime());
        orderPath.add(tempDronePos);
        return move;
    }



    /**
     * Adds return path, from restaurant back to AT, to the order path
     * Exact reverse of outward path (AT -> restaurant)
     * @return path List<LngLat> of points on reverse path
     */
    private static void addReverseOrderPath() {
        List<LngLat> revPath = orderPath;
        Collections.reverse(revPath);
        orderPath.addAll(revPath);
    }

    /**
     * Reset number of moves and points in order path for the next order calculation
     */
    private static void resetOrderCalc() {
        numOrderMoves = 0;
        orderPath.clear();
    }

    private static void printRestsDebugging(){
        for (Restaurant restaurant : Data.getRestaurants()) {
            System.out.println(restaurant.getName() + ", " + restaurant.getDistFromAT());
        }
    }
    private static void printOrdersDebugging() {
        for (Order order : Data.getValidOrders()) {
            System.out.println(order.getOrderNo() + " " + order.getRestaurant().getName() + " " + order.getRestaurant().getDistFromAT());
        }
    }

    /**
     * Write final flightpath in GeoJSON
     * @return String Json of flightpath as feature collection
     */
    public static String getFlightpathGeoJson() {
        List<Point> points = new ArrayList<>();
        // Convert lnglats to MapBox points (Latitude first! Longitude second!)
        for (LngLat lnglat : fullPath) {
            points.add(Point.fromLngLat(lnglat.getLng(), lnglat.getLat()));
        }
        // Create LineString of all points
        LineString ls = LineString.fromLngLats(points);
        // Cast LineString to Geometry, to Feature, to FeatureCollection
        FeatureCollection fc = FeatureCollection.fromFeature(Feature.fromGeometry(ls));

        // Convert feature collection to Json
        return fc.toJson();
    }

    /**
     * Getter
     * @return finalMoves Move[]
     */
    public static List<Move> getFinalMoves() {return finalMoves;}

    /**
     * Getter
     * @return finalOrders Order[]
     */
    public static List<Order> getFinalOrders() {return finalOrders;}
}
