package uk.ac.ed.inf;

import javax.lang.model.type.MirroredTypeException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Arrays;

public class Data {

    /**
     * Singleton instance of Data
     */
    private static Data DATA;
    /**
     * Restaurant[] of all restaurants retrieved from Rest server
     */
    private static Restaurant[] restaurants;
    /**
     * Order[] of all orders retrieved from Rest server
     */
    private static Order[] orders;
    /**
     * Order[] of valid orders, filtered based on OrderOutcome VALID
     */
    private static Order[] validOrders;
    /**
     * NoFlyZone[] of all no-fly zones retrieved from Rest server
     */
    private static NoFlyZone[] noFlyZones;
    /**
     * LocalDate input for getting orders on selected day
     */
    private static LocalDate orderDate = null;
    /**
     * URL input for base URL of Rest server
     */
    private static URL baseURL = null;
    /**
     * String seed for any randomizers
     */
    private static String seed = "";

    /**
     * Constructor
     */
    private Data() {}

    /**
     * Get singleton data instance or make new instance if it doesn't exist yet
     * @return Data singleton instance
     */
    public static synchronized Data getInstance() {
        if (DATA == null) {
            DATA = new Data();
        }
        return DATA;
    }

    /**
     * Gets all data from RestAPI and filters orders
     */
    public static void getData() {
        getRestData();
        filterOrders();
    }


    /**
     * Retrieves data lists (restaurants, orders, no-fly zones, and Central Area) from REST-API
     */
    private static void getRestData() {
        try{
            restaurants = Restaurant.getRestaurantsFromRESTServer();
            orders = Order.getOrdersFromRESTServer();
            noFlyZones = NoFlyZone.getNoFlyZonesFromRestServer();
            CentralArea.getInstance();
        } catch(Exception e) {
            System.err.println("Could not retrieve data from Rest API: \n" + e.getMessage());
        }

    }

    /**
     * Filters orders based on input date, validity (Order outcome)
     * Saves matching restaurant for each order
     */
    private static void filterOrders() {
        try {
            // Filter orders by input date
            orders = Arrays.stream(orders).filter(x -> LocalDate.parse(x.getOrderDate()).equals(orderDate)).toArray(Order[]::new);
            // Filter orders by validity
            validOrders = Arrays.stream(orders).filter(x -> OrderValidator.validate(x)==OrderOutcome.VALID_BUT_NOT_DELIVERED).toArray(Order[]::new);
            // Set matching restaurant for each order
            Arrays.stream(validOrders).forEach(x -> x.setRestaurant(OrderValidator.getRestaurantMatchOnOrder(Data.restaurants, x.getOrderItems())));
            //printOrders(validOrders);
        } catch(Exception e) {
            System.err.println("Could not filter orders: \n" + e.getMessage());
        }
    }

    /**
     * Setter
     * Strips whitespace from input baseURl
     * Strips ending "/" if it is present
     * @param url baseURL for Rest server
     */
    public static void setBaseURL(String url) {
        try {
            url = url.strip();
            if (url.endsWith("/")) {
                baseURL = new URL(url.substring(0, -1));
            }
            else {
                baseURL = new URL(url);
            }
        } catch (Exception e) {
            System.err.println("Could not assign input base URL.\n" + e.getMessage());
        }
    }

    /**
     * Getter
     * @return baseURL
     */
    public static URL getBaseURL() {return baseURL;}

    /**
     * Setter
     * @param restaurantsIn
     */
    public static void setRestaurants(Restaurant[] restaurantsIn) {restaurants = restaurantsIn;}

    /**
     * Getter
     * @return restaurants Restaurant[]
     */
    public static Restaurant[] getRestaurants() {return restaurants;}

    /**
     * Setter
     * @param ordersIn
     */
    public static void setOrders(Order[] ordersIn) {orders = ordersIn;}

    /**
     * Getter
     * @return orders Order[]
     */
    public static Order[] orders() {return orders;}

    /**
     * Setter
     * @param validOrdersIn
     */
    public static void setValidOrders(Order[] validOrdersIn) {validOrders = validOrdersIn;}

    /**
     * Getter
     * @return validOrders Order[]
     */
    public static Order[] getValidOrders() {return validOrders;}

    /**
     * Setter
     * @param noFlyZonesIn
     */
    public static void setNoFlyZones(NoFlyZone[] noFlyZonesIn) {noFlyZones = noFlyZonesIn;}

    /**
     * Getter
     * @return noFlyZones NoFlyZone[]
     */
    public static NoFlyZone[] getNoFlyZones() {return noFlyZones;}

    /**
     * Setter
     * @param orderDateIn
     */
    public static void setOrderDate(LocalDate orderDateIn) {orderDate = orderDateIn;}


    /**
     * Getter
     * @return orderDate LocalDate
     */
    public static LocalDate getOrderDate() {return orderDate;}

    /**
     * Setter
     * @param seedIn String
     */
    public static void setSeed(String seedIn) {seed = seedIn;}

    /**
     * Getter
     * @return seed int
     */
    public static String getSeed() {return seed;}

    /**
     * For debugging - prints list of orders
     * @param orders
     */
    public static void printOrders(Order[] orders) {
        Arrays.stream(orders).forEach(x -> System.out.println("\n" + x.getOrderNo() + " " + x.getOrderDate() + " " + x.getOutcome() + " " + x.getRestaurant().getName()));
    }
}
