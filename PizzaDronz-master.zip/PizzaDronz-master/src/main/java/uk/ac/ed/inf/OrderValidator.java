package uk.ac.ed.inf;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static uk.ac.ed.inf.OrderOutcome.*;

/**
 * Class containing all methods for validating an order
 */
public class OrderValidator {

    /**
     * Validates order based on card details and ordered items
     * @param order Order chosen for validating
         * @return outcome - null if order is valid, else INVALID
     */
    public static OrderOutcome validate(Order order) {

        try {
            Restaurant restaurantMatch;
            String[] orderItems = order.getOrderItems();

            // Check independent properties
            OrderOutcome outcome = checkCardNumberValid(order);
            if (checkCardNumberValid(order) == VALID_BUT_NOT_DELIVERED) {
                if (checkExpiryDateValid(order) == VALID_BUT_NOT_DELIVERED) {
                    if (checkCvvValid(order) == VALID_BUT_NOT_DELIVERED) {
                        if (checkPizzaCountValid(orderItems)== VALID_BUT_NOT_DELIVERED) {
                            // Check dependent properties
                            if (checkPizzaDefined(Data.getRestaurants(), orderItems[0]) == VALID_BUT_NOT_DELIVERED) {
                                // Get menu matching order
                                restaurantMatch = getRestaurantMatchOnOrder(Data.getRestaurants(), orderItems);
                                // Check pizza combination all belongs to that menu
                                if (checkPizzaCombinationValid(restaurantMatch, orderItems) == VALID_BUT_NOT_DELIVERED) {
                                    // Check total price is correct
                                    if (checkTotalValid(restaurantMatch.getMenu(), orderItems, order) != VALID_BUT_NOT_DELIVERED)
                                        return INVALID;
                                    else
                                        return VALID_BUT_NOT_DELIVERED;
                                }
                            }
                        }
                    }
                }
            }
            return outcome;

        } catch (Exception e) {
            System.err.println("Error while validating order: " + e.getMessage());
            return OrderOutcome.INVALID;
        }
    }

    /**
     * Checks if the credit card number is valid.
     * Uses regex to check for Visa, Mastercard, and Amex card number formats.
     * Uses Luhn algorithm to calculate checksum.
     * @return OrderOutcome.INVALID_CARD_NUMBER
     */
    private static OrderOutcome checkCardNumberValid(Order order)
    {
        try {
            String cardNum = order.getCreditCardNumber();
            // Card must be 16 digits long
            if (cardNum.length() == 16) {
                // Regex to check card company is valid
                // From https://www.baeldung.com/java-validate-cc-number
                // Visa
                String visaRegex = "^4[0-9]{0,}$";
                Pattern visaPattern = Pattern.compile(visaRegex);
                Matcher visaMatcher = visaPattern.matcher(cardNum);
                // Mastercard
                String mcRegex = "^(5[1-5]|222[1-9]|22[3-9]|2[3-6]|27[01]|2720)[0-9]{0,}$";
                Pattern mcPattern = Pattern.compile(mcRegex);
                Matcher mcMatcher = mcPattern.matcher(cardNum);
                // If card number matches either Visa or Mastercard
                if (visaMatcher.matches() || mcMatcher.matches())
                    if (checkLuhnAlgorithmValid(cardNum)) {
                        return VALID_BUT_NOT_DELIVERED;
                    }
            }
            return OrderOutcome.INVALID_CARD_NUMBER;
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return OrderOutcome.INVALID_CARD_NUMBER;
        }
    }

    /**
     * Validates checksum of credit card number via Luhn algorithm.
     * @return Boolean - true if ccn is valid; else false
     */
    private static Boolean checkLuhnAlgorithmValid(String cardNumber)
    {
        try {
            int n = cardNumber.length();
            int sum = 0;
            int[] cardNums = new int[n];
            // Get card number as integer array
            for (int i = 0; i < n; i++) {
                cardNums[i] = Integer.parseInt(String.valueOf(cardNumber.charAt(i)));
            }
            // Luhn ...
            int parity = n % 2;
            for (int i = n-1; i >= 0; i--) {
                if (i % 2 == parity) {
                    if (cardNums[i] > 4)
                        sum += cardNums[i] * 2 - 9;
                    else
                        sum += cardNums[i] * 2;
                }
                else
                    sum += cardNums[i];
            }
            return (sum % 10 == 0);
        } catch (Exception e) {
            System.err.println("Error using Luhn Algorithm to validate card: \n" + e.getMessage());
            return false;
        }
    }

    /**
     * Checks if the card expiry date is valid (i.e. not an empty field, and that the card is not expired).
     * @return OrderOutcome.INVALID_EXPIRY_DATE
     */
    private static OrderOutcome checkExpiryDateValid(Order order) {
        try {
            DateTimeFormatter dt = DateTimeFormatter.ofPattern("MM/uu");
            YearMonth expiryDate = YearMonth.parse(order.getCreditCardExpiry(), dt);
            // If card expires after today, fine
            if (expiryDate.isAfter(YearMonth.now()))
                return VALID_BUT_NOT_DELIVERED;
            // Else return "invalid" outcome
            return OrderOutcome.INVALID_EXPIRY_DATE;
        } catch (DateTimeException e) {
            return INVALID_EXPIRY_DATE;
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return OrderOutcome.INVALID_EXPIRY_DATE;
        }
    }

    /**
     * Checks if the cvv is valid via regex.
     * @return OrderOutcome.INVALID_CVV
     */
    private static OrderOutcome checkCvvValid(Order order)
    {
        try {
            String cvv = order.getCvv();
            // Return "invalid" outcome if CVV is null
            if (cvv == null)
                return OrderOutcome.INVALID_CVV;
            // All chars must be digits; length must be 3 or 4 digits
            String regex = "^[0-9]{3}$";
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(cvv);
            // If it matches, return null
            if (m.matches())
                return VALID_BUT_NOT_DELIVERED;
            // Otherwise, return "invalid" outcome
            return OrderOutcome.INVALID_CVV;
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return OrderOutcome.INVALID_CVV;
        }
    }

    /**
     * Checks if the total cost of the order is valid (i.e. a correct sum of the menu items' prices).
     * Assumes all pizzas are from SAME restaurant menu - PIZZA_COMBINATION dependency
     * @return OrderOutcome.INVALID_TOTAL
     */
    private static OrderOutcome checkTotalValid(MenuItem[] menuItems, String[] orderItems, Order order)
    {
        try {
            int total = 0;
            // For each pizza in order
            for (String orderItem : orderItems) {
                // If it's in the menu
                for (MenuItem menuItem : menuItems) {
                    // Add menu item price
                    if (menuItem.getName().equals(orderItem)) {
                        total += menuItem.getPriceInPence();
                    }
                }
                // If order total matches calculated total, return valid
                if (total == order.getPriceTotalInPence()) {
//                    System.out.println("price matched");
                    return VALID_BUT_NOT_DELIVERED;
                }
            }
//            System.out.println("price didn't match");
            return OrderOutcome.INVALID_TOTAL;
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
            return OrderOutcome.INVALID_TOTAL;
        }
    }

    /**
     * Checks if a pizza is listed in any restaurant's menu.
     * @param restaurants - Restaurant[] of all restaurants
     * @param pizza - String name of pizza
     * @return OrderOutcome.INVALID_PIZZA_NOT_DEFINED
     */
    private static OrderOutcome checkPizzaDefined(Restaurant[] restaurants, String pizza)
    {
        try {
            // For each restaurant
            for (Restaurant restaurant : restaurants) {
                // Get menu item names match pizza name
                if (checkPizzaInMenu(restaurant.getMenu(), pizza))
                    return VALID_BUT_NOT_DELIVERED;
            }
            return OrderOutcome.INVALID_PIZZA_NOT_DEFINED;
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return OrderOutcome.INVALID_PIZZA_NOT_DEFINED;
        }
    }

    /**
     * Checks if the pizza count is valid (not less than 1 or more than 4)
     * @return OrderOutcome.INVALID_PIZZA_COUNT
     */
    private static OrderOutcome checkPizzaCountValid(String[] orderItems)
    {
        try {
            // If count 1<x<4,return valid outcome
            if (1 <= orderItems.length && orderItems.length <= 4)
                return VALID_BUT_NOT_DELIVERED;
            // Else return "invalid" outcome
            return OrderOutcome.INVALID_PIZZA_COUNT;
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return OrderOutcome.INVALID_PIZZA_COUNT;
        }
    }

    /**
     * Checks if the pizza combination is valid (i.e. all pizzas are from one same restaurant)
     * ASSUMES menu has been found that matches first pizza at least
     * @param restaurant - Restaurant that matches first pizza on order
     * @param orderItems - String[] pizza names in order
     * @return OrderOutcome.INVALID_PIZZA_COMBINATION_MULTIPLE_SUPPLIERS
     */
    private static OrderOutcome checkPizzaCombinationValid(Restaurant restaurant, String[] orderItems) {
        try {
            // Return valid if only 1 pizza
            if (orderItems.length == 1)
                return VALID_BUT_NOT_DELIVERED;
            // For each pizza in order
            for (String item : orderItems) {
                // If pizza not in menu
                if (!checkPizzaInMenu(restaurant.getMenu(), item))
                    // Return error outcome
                    return OrderOutcome.INVALID_PIZZA_COMBINATION_MULTIPLE_SUPPLIERS;
            }
            return VALID_BUT_NOT_DELIVERED;
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return OrderOutcome.INVALID_PIZZA_COMBINATION_MULTIPLE_SUPPLIERS;
        }
    }

    /**
     * Checks if a pizza is in a given menu
     * @param menuItems MenuItem[] array of items on chosen menu
     * @param pizza String name of pizza
     * @return Boolean - if pizza is / is not in menu
     */
    private static Boolean checkPizzaInMenu(MenuItem[] menuItems, String pizza) {
        for (MenuItem item : menuItems) {
            if (item.getName().equals(pizza))
                return true;
        }
        return false;
    }

    /**
     * Loops through restaurant matches until it finds menu has the first pizza from the order
     * @param restaurants Restaurant[] array of all restaurants
     * @param orderItems String[] pizza names in selected order
     * @return MenuItem[] menu
     */

    public static Restaurant getRestaurantMatchOnOrder (Restaurant[] restaurants, String[] orderItems) {
        for (Restaurant restaurant : restaurants) {
            MenuItem[] menu = restaurant.getMenu();
            if (checkPizzaInMenu(menu, orderItems[0])) {
                return restaurant;
            }
        }
        return null;
    }
}
