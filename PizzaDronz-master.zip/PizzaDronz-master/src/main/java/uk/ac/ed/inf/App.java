package uk.ac.ed.inf;

import java.net.URL;
import java.time.LocalDate;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {

        // Set input arguments in Data Class: [0] date (YYYY-MM-DD); [1] base URL; [2] random seed
        try {
            Data.setOrderDate(LocalDate.parse(args[0]));
            Data.setBaseURL(args[1]);
            Data.setSeed(args[2]);
        } catch (Exception e) {
            System.err.println("Could not set inputs.\nError: " + e.getMessage());
            System.out.println("Please try again.");
        }

        Data.getInstance();
        Data.getData();

        // List of Moves along path
        String flightpath = Flightpath.getFlightpath();
        InputOutput.writeFlightpathFile();
        // List of orders on flightpath
        InputOutput.writeDeliveriesFile();
        // GeoJson LngLat locations of each move
        InputOutput.writeDronePathFile();
    }
}
