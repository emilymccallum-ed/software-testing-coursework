package uk.ac.ed.inf;

/**
 * Enum holding compass directions (primary, secondary, tertiary) and their respective unit circle angles in degrees.
 */
public enum Direction {

    // 22.5 degrees between each
    // East is 0; circle goes anti-clockwise
    /**
     * Hover = -1 degrees, i.e. exceptional value
     */
    Hover (-1),
    /**
     * East = 0
     */
    E(0),
    /**
     * EastNorthEast = 22.5
     */
    ENE(22.5),
    /**
     * NorthEast = 45
     */
    NE(45),
    /**
     * NorthNorthEast = 67.5
     */
    NNE(67.5),
    /**
     * North = 90
     */
    N(90),
    /**
     * NorthNorthWest = 112.5
     */
    NNW(112.5),
    /**
     * NorthWest = 135
     */
    NW(135),
    /**
     * WestNorthWest = 157.5
     */
    WNW(157.5),
    /**
     * West = 180
     */
    W(180),
    /**
     * WestSouthWest = 202.5
     */
    WSW(202.5),
    /**
     * SouthWest = 225
     */
    SW(225),
    /**
     * SouthSouthWest = 247.5
     */
    SSW(247.5),
    /**
     * South = 270
     */
    S(270),
    /**
     * SouthSouthEast = 292.5
     */
    SSE(292.5),
    /**
     * SouthEast = 315
     */
    SE(315),
    /**
     * EastSouthEast = 337.5
     */
    ESE(337.5);

    /**
     * Direction angle in degrees
     */
    private final double angle;

    /**
     * Constructor
     * @param angle - direction degree amount (East = 0)
     */
    Direction(double angle) {this.angle = angle;}

    /**
     * Getter
     * @return angle for enum Direction value in degrees
     */
    public double getAngle()
    {
        return this.angle;
    }


}