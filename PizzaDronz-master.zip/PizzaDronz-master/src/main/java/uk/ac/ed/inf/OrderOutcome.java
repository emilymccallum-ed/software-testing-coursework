package uk.ac.ed.inf;

/**
 * Enum for Order Outcomes, for use in validation checks.
 */
public enum OrderOutcome {
    /**
     * Order is valid and delivered, i.e. is on final flightpath
     */
    DELIVERED,
    /**
     * Order is valid but not delivered, i.e. not put on final flightpath
     */
    VALID_BUT_NOT_DELIVERED,
    /**
     * Invalid credit card number
     */
    INVALID_CARD_NUMBER,
    /**
     * Invalid credit card expiry date
     */
    INVALID_EXPIRY_DATE,
    /**
     * Invalid credit card cvv
     */
    INVALID_CVV,
    /**
     * Invalid total price of order
     */
    INVALID_TOTAL,
    /**
     * Invalid as pizza could not be found on any restaurant's menu
     */
    INVALID_PIZZA_NOT_DEFINED,
    /**
     * Invalid because number of pizzas is not between 1 and 4
     */
    INVALID_PIZZA_COUNT,
    /**
     * Invalid pizza combination because pizzas came from different restaurants
     */
    INVALID_PIZZA_COMBINATION_MULTIPLE_SUPPLIERS,
    /**
     * Invalid - generic
     */
    INVALID
}