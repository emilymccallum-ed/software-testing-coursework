package uk.ac.ed.inf;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.fasterxml.jackson.core.type.TypeReference;

/**
 * Class for storing Restaurant objects deserialized from JSON from Rest API.
 * Contains Restaurant name, location, menu items, and distance from Appleton Tower.
 */
public class Restaurant {

    /**
     * Restaurant name
     */
    @JsonProperty("name")
    private String name;

    /**
     * Unwrapped lng and lat to LngLat
     */
    @JsonUnwrapped
    private LngLat location;

    /**
     * List of Menu items, i.e. the name and price of each pizza on their menu
     */
    @JsonProperty("menu")
    private MenuItem[] menuItems;

    @JsonIgnore
    private double distFromAT;

    /**
     * Constructor
     */
    private Restaurant() {}

    /**
     * Gets list of all restaurants from Rest API, by deserializing JSON into Restaurant objects
     * @return Restaurant[] - list of all restaurants
     */
    public static Restaurant[] getRestaurantsFromRESTServer() {
        return InputOutput.deserialize("/restaurants", new TypeReference<>() {});
    }

    /**
     * Getter
     * @return name
     */
    public String getName() {return this.name;}


    /**
     * Getter
     * @return location
     */
    public LngLat getLocation() {return this.location;}

    /**
     * Getter
     * @return menuItems
     */
    public MenuItem[] getMenu() {return this.menuItems;}

    /**
     * Getter
     * @return double distance from Appleton Tower
     */
    public double getDistFromAT() {return this.distFromAT;}

    /**
     * Setter
     * @param distFromAT double
     */
    public void setDistFromAT(double distFromAT) {
        this.distFromAT = distFromAT;
    }
}
