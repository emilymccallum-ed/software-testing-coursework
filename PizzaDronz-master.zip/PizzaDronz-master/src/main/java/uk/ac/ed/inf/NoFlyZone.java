package uk.ac.ed.inf;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;

import java.util.ArrayList;
import java.util.List;

/**
 * Class containing properties of no-fly zone
 */
public class NoFlyZone {

    /**
     * String name of zone
     */
    @JsonProperty("name")
    private String name;

    /**
     * List of doubles - coordinates for zone vertices
     */
    @JsonProperty("coordinates")
    private List<double[]> coordinates;

    /**
     * Coordinates as List of LngLats
     */
    private List<LngLat> points = new ArrayList<>();
    /**
     * Constructor
     * Retrieves points from RestServer via deserialization with RestClient
     */
    private NoFlyZone() {};

    /**
     * Get all no-fly zones and their coordinates from Rest API server
     * @return NoFlyZone[] - list of all no-fly zones
     */
    public static NoFlyZone[] getNoFlyZonesFromRestServer() {
        NoFlyZone[] zones = InputOutput.deserialize("/noflyzones", new TypeReference<>() {});
        for (NoFlyZone zone : zones) {
            zone.setPoints();
        }
        return zones;
    }

    /**
     * Convert List<double[]> coordinates to List<LngLat> points
     */
    public void setPoints() {
        for (double[] coord : coordinates) {
            points.add(new LngLat(coord[0], coord[1]));
        }
    }

    /**
     * Getter
     * @return coordinates as list of doubles
     */
    public List<double[]> getCoordinates() {return this.coordinates;}

    /**
     * Getter
     * @return coordinates as list of LngLats
     */
    public List<LngLat>  getPoints() {return this.points;}
}
