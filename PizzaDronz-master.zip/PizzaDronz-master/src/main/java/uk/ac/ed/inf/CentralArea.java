package uk.ac.ed.inf;

import com.fasterxml.jackson.core.type.TypeReference;

import java.util.List;

/**
 * Singleton class to hold CentralArea polygon boundaries. Stores a list of CentralArea polygon vertices (CentralAreaPoint) retrieved from Rest API.
 */
public class CentralArea {

    /**
     * Holds the Singleton instance of Central Area.
     */
    private static CentralArea CENTRAL_AREA;

    /**
     * Holds the polygon boundary points retrieved from Rest API.
     */
    private static List<LngLat> points;

    /**
     * Constructor
     * Retrieves CentralArea points from Rest server
     * Deserializes from JSON and stores data as a List of CentralAreaPoint objects
     */
    private CentralArea() {
        points = InputOutput.deserialize("/centralarea", new TypeReference<>() {});
    }

    /**
     * Retrieves static singleton instance
     * If no instance has been set, creates one
     * @return CentralArea singleton instance
     */
    public static synchronized CentralArea getInstance() {
        if (CENTRAL_AREA == null)
            CENTRAL_AREA = new CentralArea();

        return CENTRAL_AREA;
    }

    /**
     * Getter
     * @return points - LngLat list of Central Area vertices
     */
    public static List<LngLat> getPoints()
    {
        return points;
    }
}
